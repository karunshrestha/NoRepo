﻿/*
 * Created by Ranorex
 * User: Karun Shrestha
 * Date: 2/11/2017
 * Time: 1:27 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace CCHSSmokeTest.CodeModules
{
	/// <summary>
	/// Description of LoginPN.
	/// </summary>
	[TestModule("F985BEC5-BE91-4140-B4EA-7B068EF1F5ED", ModuleType.UserCode, 1)]
	public class LoginPN : ITestModule
	{
		/// <summary>
		/// Constructs a new instance.
		/// </summary>
		public LoginPN()
		{
			// Do not delete - a parameterless constructor is required!
		}

		string _varPassword = "Password1";
		[TestVariable("00b98c81-4cec-42b8-9d5a-202df95c47dc")]
		public string varPassword
		{
			get { return _varPassword; }
			set { _varPassword = value; }
		}

		string _varLogin = "karun.shrestha@newoceanhealth.com";
		[TestVariable("66b6f84b-e388-4894-be89-10fcb088b9c1")]
		public string varLogin
		{
			get { return _varLogin; }
			set { _varLogin = value; }
		}

		/// <summary>
		/// Performs the playback of actions in this module.
		/// </summary>
		/// <remarks>You should not call this method directly, instead pass the module
		/// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
		/// that will in turn invoke this method.</remarks>
		void ITestModule.Run()
		{
			Mouse.DefaultMoveTime = 300;
			Keyboard.DefaultKeyPressTime = 100;
			Delay.SpeedFactor = 1.0;
			
			var repo = SmokeTestRepositoryKS.Instance;
			
			var email = repo.NewOceanAdminPortal.Login.Email;
			var password = repo.NewOceanAdminPortal.Login.Password;
			var loginButton = repo.NewOceanAdminPortal.Login.LoginBtn;
			
			
			
			
			fillInputField (email, _varLogin);
			fillInputField (password, _varPassword);
			Report.Log(ReportLevel.Info, "Keyboard", "Key sequence '{Tab}'.");
            Keyboard.Press("{Tab}");
            Delay.Milliseconds(1500);
			loginButton.Click();
			Delay.Milliseconds(2000);
			
			// Validations for each loop
			
			
			int currentIndex = TestCaseNode.Current.DataContext.CurrentRowIndex;
			Report.Info ("Current Index: " + currentIndex);
			
			
			if(currentIndex == 1)
				
			{
				Ranorex.DivTag alertDiv = Host.Local.FindSingle <Ranorex.DivTag> ("/dom[@domain='qa.carecamhealthsystems.com']//div[#'loginAlert']");
				Report.Info(alertDiv.InnerText);
				Validate.IsTrue(alertDiv.InnerText.Contains("Please correct"));
				
				Ranorex.SpanTag mySpanTag = Host.Local.FindSingle <Ranorex.SpanTag> ("/dom[@domain='qa.carecamhealthsystems.com']//span[#'emailVal']/span[@innertext~'^Email\\ Address\\ is\\ required']");
				Report.Info(mySpanTag.InnerText);
				Validate.IsTrue(mySpanTag.InnerText.Contains("Email Address"));
				
				
				Ranorex.SpanTag mySpanTagPassword = Host.Local.FindSingle <Ranorex.SpanTag> ("/dom[@domain='qa.carecamhealthsystems.com']//span[#'passwordVal']/span[@innertext='The Password is required.']");
				Report.Info(mySpanTagPassword.InnerText);
				Validate.IsTrue(mySpanTagPassword.InnerText.Contains("The Password"));
				
			}
			
			else if (currentIndex == 2)
			{
				Ranorex.DivTag alertDiv = Host.Local.FindSingle <Ranorex.DivTag> ("/dom[@domain='qa.carecamhealthsystems.com']//div[#'loginAlert']");
				Report.Info(alertDiv.InnerText);
				Validate.IsTrue(alertDiv.InnerText.Contains("Please correct"));
				
				Ranorex.SpanTag mySpanTag = Host.Local.FindSingle <Ranorex.SpanTag> ("/dom[@domain='qa.carecamhealthsystems.com']//span[#'emailVal']/span[@innertext~'^Email\\ Address\\ is\\ required']");
				Report.Info(mySpanTag.InnerText);
				Validate.IsTrue(mySpanTag.InnerText.Contains("Email Address"));
			}
			
			else if (currentIndex == 3)
				
			{
				Ranorex.DivTag alertDiv = Host.Local.FindSingle <Ranorex.DivTag> ("/dom[@domain='qa.carecamhealthsystems.com']//div[#'loginAlert']");
				Report.Info(alertDiv.InnerText);
				Validate.IsTrue(alertDiv.InnerText.Contains("Please correct"));
				
				Ranorex.SpanTag mySpanTagPassword = Host.Local.FindSingle <Ranorex.SpanTag> ("/dom[@domain='qa.carecamhealthsystems.com']//span[#'passwordVal']/span[@innertext='The Password is required.']");
				Report.Info(mySpanTagPassword.InnerText);
				Validate.IsTrue(mySpanTagPassword.InnerText.Contains("The Password"));
			}
			
			else if (currentIndex == 4 || currentIndex ==5)
			{
				
				Ranorex.DivTag loginAlert = Host.Local.FindSingle <Ranorex.DivTag> ("/dom[@domain='qa.carecamhealthsystems.com']//div[#'loginAlert']");
				Report.Info(loginAlert.InnerText);
				Validate.IsTrue(loginAlert.InnerText.Contains("credentials"));
			}
			
			else if (currentIndex == 6)
			{
				var home = repo.NewOceanAdminPortal.Home.Home;
				Report.Info(home.InnerText);
				Validate.IsTrue(home.InnerText.Contains("Home"));
			}
			
		}
		
		public void fillInputField(InputTag inputTagName, String value){
			inputTagName.Click();
			inputTagName.InnerText = ""; // clear
			inputTagName.PressKeys(value);
		}
		
	}
	
}
